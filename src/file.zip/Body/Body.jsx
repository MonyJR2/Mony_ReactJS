import React from 'react'

export const Body = () => {
    return (
        <div className='body'>
            <div className="txt">

            </div>
            <div className="login">

            </div>
        </div>
    )
}
