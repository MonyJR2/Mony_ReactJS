import React from 'react'
import '../Header/bar.css'
import {Link} from 'react-router-dom'
export const Bar = () => {
    return (
        <div className='bar-head'>
            <li>Logo</li>
            <nav className='nav-item'>
                <li><Link to="/Body">Home</Link></li>
                <li><Link to="/Service">Service</Link></li>
                <li><Link to="Contact">Contact</Link></li>
                <li><Link to="Aboute">About</Link></li>
            </nav>
            <div className="search">
                <input type="search" />
                <label>Search</label>
            </div>

        </div>
    )
}
