import React from 'react'
import { Bar } from './Header/Bar'
import { Body } from './Body/Body'

export const App = () => {
  return (
    <div>
      <header>
       <Bar /> 
      </header>
      <section>
        <Body/>
      </section>
    </div>
  )
}
